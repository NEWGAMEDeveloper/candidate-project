package com.deepInsight.candidateinfo.controller;public class OcrController {
}
