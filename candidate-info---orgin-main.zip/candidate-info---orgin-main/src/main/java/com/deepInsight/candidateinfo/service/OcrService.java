package com.deepInsight.candidateinfo.service;public class OcrService {
}
