package com.deepInsight.candidateinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandidateInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
